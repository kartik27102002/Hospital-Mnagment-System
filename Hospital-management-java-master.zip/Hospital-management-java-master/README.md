# Hospital-management-java
This is my hospital management system project made by JAVA.

There are multiple login pages for patients, hospital workers etc.
On the first page there is a MENU which you want to login as patient or hospital worker.

MENU is the form where you are selecting that USER TYPE.

hastakayıtol - for patient registration to the system. (first login)
hastagiris - for the patient login.
hastasistem - main form for patients after successful login.

hastanegiris - for the hospital workers. (first login)
hastanesistem - main form for hospital workers after successful login.

DATABASE: db-derby

Thank you.
